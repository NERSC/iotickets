#!/bin/bash
#SBATCH -p regular 
#SBATCH -N 16
#SBATCH -t 00:10:00
#SBATCH -J gdb
#SBATCH -e gdb%j.err
#SBATCH -o gdb%j.out
srun -n 512 ./gdb_4.x $SLURM_JOBID $prevjobid
